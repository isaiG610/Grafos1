package backend;

/**
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
public class Vertice {

    private final String id;
    private String nombre;
    private String tipo;
    private String estado;
    private double capacidad;

    public Vertice(String id, String nombre, String tipo, String estado, double capacidad) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.estado = estado;
        this.capacidad = capacidad;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getTipo() { return tipo; }
    public String getEstado() { return estado; }
    public double getCapacidad() { return capacidad; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setCapacidad(double capacidad) { this.capacidad = capacidad; }

    @Override
    public String toString() {
        return "ID: " + id
                + "\nNombre: " + nombre
                + "\nTipo: " + tipo
                + "\nEstado: " + estado
                + "\nCapacidad: " + Grafo.formatear(capacidad);
    }
}
