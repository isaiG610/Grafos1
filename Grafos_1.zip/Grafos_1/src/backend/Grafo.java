package backend;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public class Grafo {

    public enum Conectividad { FUERTEMENTE_CONEXO, DEBILMENTE_CONEXO, DESCONECTADO }

    private final Map<String, Vertice> vertices = new LinkedHashMap<>();
    private final Map<String, Map<String, Arista>> adyacencia = new LinkedHashMap<>();

   

    public void agregarVertice(String id, String nombre, String tipo, String estado, double capacidad) {
        validarId(id);
        validarTexto(nombre, "nombre");
        validarTexto(tipo, "tipo");
        validarTexto(estado, "estado");
        if (Double.isNaN(capacidad) || Double.isInfinite(capacidad) || capacidad < 0) {
            throw new IllegalArgumentException("La capacidad debe ser un número finito mayor o igual a 0.");
        }
        if (vertices.containsKey(id)) {
            throw new IllegalArgumentException("Ya existe un vértice con el ID '" + id + "'.");
        }
        vertices.put(id, new Vertice(id, nombre, tipo, estado, capacidad));
        adyacencia.put(id, new LinkedHashMap<>());
    }

    public Vertice buscarVertice(String id) {
        return id == null ? null : vertices.get(id);
    }

    public boolean existeVertice(String id) {
        return id != null && vertices.containsKey(id);
    }

  
    public void eliminarVertice(String id) {
        if (!existeVertice(id)) {
            throw new IllegalArgumentException("No existe un vértice con el ID '" + id + "'.");
        }
        vertices.remove(id);
        adyacencia.remove(id);
        for (Map<String, Arista> salientes : adyacencia.values()) {
            salientes.remove(id);
        }
    }

    // ------------------------------------------------------------------- aristas

    public void agregarArista(String origen, String destino, double peso) {
        if (!existeVertice(origen)) {
            throw new IllegalArgumentException("El vértice origen '" + origen + "' no existe.");
        }
        if (!existeVertice(destino)) {
            throw new IllegalArgumentException("El vértice destino '" + destino + "' no existe.");
        }
        if (Double.isNaN(peso) || Double.isInfinite(peso) || peso <= 0) {
            throw new IllegalArgumentException("El peso debe ser un número finito y positivo.");
        }
        if (origen.equals(destino)) {
            throw new IllegalArgumentException("No se permiten rutas de un vértice hacia sí mismo.");
        }
        if (adyacencia.get(origen).containsKey(destino)) {
            throw new IllegalArgumentException("Ya existe la ruta " + origen + " -> " + destino
                    + ". Elimínela primero si desea cambiar su peso.");
        }
        adyacencia.get(origen).put(destino, new Arista(origen, destino, peso));
    }

    public boolean existeArista(String origen, String destino) {
        return existeVertice(origen) && adyacencia.get(origen).containsKey(destino);
    }

    public void eliminarArista(String origen, String destino) {
        if (!existeVertice(origen)) {
            throw new IllegalArgumentException("El vértice origen '" + origen + "' no existe.");
        }
        if (!existeVertice(destino)) {
            throw new IllegalArgumentException("El vértice destino '" + destino + "' no existe.");
        }
        if (adyacencia.get(origen).remove(destino) == null) {
            throw new IllegalArgumentException("No existe la ruta " + origen + " -> " + destino + ".");
        }
    }

    // ----------------------------------------------------------------- consultas

    public boolean estaVacio() { return vertices.isEmpty(); }

    public int cantidadVertices() { return vertices.size(); }

    public int cantidadAristas() {
        int total = 0;
        for (Map<String, Arista> m : adyacencia.values()) total += m.size();
        return total;
    }

    public Collection<Vertice> getVertices() { return vertices.values(); }

    public List<Arista> getAristas() {
        List<Arista> lista = new ArrayList<>();
        for (Map<String, Arista> m : adyacencia.values()) lista.addAll(m.values());
        return lista;
    }

    /** Grado de salida y de entrada de un vértice (para mostrar al buscar). */
    public int gradoSalida(String id) {
        return existeVertice(id) ? adyacencia.get(id).size() : 0;
    }

    public int gradoEntrada(String id) {
        int g = 0;
        for (Map<String, Arista> m : adyacencia.values()) if (m.containsKey(id)) g++;
        return g;
    }

    /** Elimina todos los vértices y aristas. */
    public void destruir() {
        vertices.clear();
        adyacencia.clear();
    }

    // ---------------------------------------------------------------- recorridos

    /** Recorrido en anchura desde un vértice origen. Devuelve los IDs en orden de visita. */
    public List<String> bfs(String inicio) {
        exigirVertice(inicio);
        List<String> orden = new ArrayList<>();
        Set<String> visitados = new HashSet<>();
        Deque<String> cola = new ArrayDeque<>();
        visitados.add(inicio);
        cola.add(inicio);
        while (!cola.isEmpty()) {
            String actual = cola.poll();
            orden.add(actual);
            for (String vecino : adyacencia.get(actual).keySet()) {
                if (visitados.add(vecino)) cola.add(vecino);
            }
        }
        return orden;
    }

    /** Recorrido en profundidad desde un vértice origen (iterativo, sin riesgo de desbordar la pila). */
    public List<String> dfs(String inicio) {
        exigirVertice(inicio);
        List<String> orden = new ArrayList<>();
        Set<String> visitados = new HashSet<>();
        Deque<String> pila = new ArrayDeque<>();
        pila.push(inicio);
        while (!pila.isEmpty()) {
            String actual = pila.pop();
            if (!visitados.add(actual)) continue;
            orden.add(actual);
            // Se apilan en orden inverso para visitar primero al vecino que se insertó primero.
            List<String> vecinos = new ArrayList<>(adyacencia.get(actual).keySet());
            for (int i = vecinos.size() - 1; i >= 0; i--) {
                if (!visitados.contains(vecinos.get(i))) pila.push(vecinos.get(i));
            }
        }
        return orden;
    }

    // ------------------------------------------------------------------- matriz

    /** Matriz de pesos: [i][j] = peso de la arista i -> j, o 0 si no existe. */
    public double[][] matrizAdyacencia() {
        List<String> ids = new ArrayList<>(vertices.keySet());
        int n = ids.size();
        double[][] m = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (Arista a : adyacencia.get(ids.get(i)).values()) {
                m[i][ids.indexOf(a.getDestino())] = a.getPeso();
            }
        }
        return m;
    }

    public List<String> idsEnOrden() { return new ArrayList<>(vertices.keySet()); }

    // ------------------------------------------------------------- conectividad

    /**
     * Fuertemente conexo: desde cualquier vértice se alcanza a todos los demás
     * (se comprueba desde un vértice en el grafo y en su inverso).
     * Débilmente conexo: ignorando la dirección de las aristas, todo es alcanzable.
     * Un grafo vacío se considera desconectado.
     */
    public Conectividad evaluarConectividad() {
        if (vertices.isEmpty()) return Conectividad.DESCONECTADO;
        String raiz = vertices.keySet().iterator().next();
        int n = vertices.size();

        // Alcanzables desde la raíz siguiendo las aristas
        int adelante = alcanzables(raiz, false, false);
        // Alcanzables hacia la raíz (grafo transpuesto)
        int atras = alcanzables(raiz, true, false);
        if (adelante == n && atras == n) return Conectividad.FUERTEMENTE_CONEXO;

        // Ignorando direcciones
        if (alcanzables(raiz, false, true) == n) return Conectividad.DEBILMENTE_CONEXO;
        return Conectividad.DESCONECTADO;
    }

    private int alcanzables(String raiz, boolean invertido, boolean ambosSentidos) {
        Set<String> visitados = new HashSet<>();
        Deque<String> pila = new ArrayDeque<>();
        visitados.add(raiz);
        pila.push(raiz);
        while (!pila.isEmpty()) {
            String actual = pila.pop();
            for (String otro : vertices.keySet()) {
                if (visitados.contains(otro)) continue;
                boolean directa = adyacencia.get(actual).containsKey(otro);
                boolean inversa = adyacencia.get(otro).containsKey(actual);
                boolean hayCamino = ambosSentidos ? (directa || inversa) : (invertido ? inversa : directa);
                if (hayCamino) {
                    visitados.add(otro);
                    pila.push(otro);
                }
            }
        }
        return visitados.size();
    }

    // ------------------------------------------------------------- validaciones

    private void exigirVertice(String id) {
        if (!existeVertice(id)) {
            throw new IllegalArgumentException("No existe un vértice con el ID '" + id + "'.");
        }
    }

    private static void validarId(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("El ID del vértice es obligatorio.");
        }
        if (!id.matches("[A-Za-z0-9_-]+")) {
            throw new IllegalArgumentException("El ID solo puede contener letras, números, '-' o '_' (sin espacios).");
        }
    }

    private static void validarTexto(String valor, String campo) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("El campo '" + campo + "' no puede estar vacío.");
        }
    }

    /** Muestra 5.0 como "5" y 2.5 como "2.5". */
    public static String formatear(double d) {
        return d == Math.rint(d) && Math.abs(d) < 1e15 ? String.valueOf((long) d) : String.valueOf(d);
    }
}
