package backend;

/**
 Gonzalez Nuñez Isai
 Zuñiga de Leon Bryan
 */
public class Arista {

    private final String origen;
    private final String destino;
    private final double peso;

    public Arista(String origen, String destino, double peso) {
        this.origen = origen;
        this.destino = destino;
        this.peso = peso;
    }

    public String getOrigen() { return origen; }
    public String getDestino() { return destino; }
    public double getPeso() { return peso; }

    @Override
    public String toString() {
        return origen + " -> " + destino + " (" + Grafo.formatear(peso) + ")";
    }
}
