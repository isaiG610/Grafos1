/*
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
package frontend;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.RenderingHints;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class GraphCanvasPanel extends JPanel {
    
    
    class NodoGrafico {
        String id; int x, y;
        public NodoGrafico(String id, int x, int y) { this.id = id; this.x = x; this.y = y; }
    }
    class AristaGrafica {
        String origen, destino; double peso;
        public AristaGrafica(String origen, String destino, double peso) {
            this.origen = origen; this.destino = destino; this.peso = peso;
        }
    }

    private Map<String, NodoGrafico> nodos = new HashMap<>();
    private List<AristaGrafica> aristas = new ArrayList<>();

    public GraphCanvasPanel() {
        setBackground(Color.WHITE); 
    }

    public void agregarNodoV(String id, int x, int y) {
        nodos.put(id, new NodoGrafico(id, x, y));
        repaint(); 
    }

    public void agregarAristaV(String origen, String destino, double peso) {
        aristas.add(new AristaGrafica(origen, destino, peso));
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Suavizar bordes

        
        g2.setColor(Color.BLACK);
        for (AristaGrafica a : aristas) {
            NodoGrafico n1 = nodos.get(a.origen);
            NodoGrafico n2 = nodos.get(a.destino);
            if (n1 != null && n2 != null) {
                g2.drawLine(n1.x, n1.y, n2.x, n2.y);
                
                g2.setColor(Color.RED);
                g2.drawString(String.valueOf(a.peso), (n1.x + n2.x)/2, (n1.y + n2.y)/2);
                g2.setColor(Color.BLACK);
            }
        }

        
        int radio = 15;
        for (NodoGrafico n : nodos.values()) {
            g2.setColor(Color.CYAN);
            g2.fillOval(n.x - radio, n.y - radio, radio * 2, radio * 2);
            g2.setColor(Color.BLACK);
            g2.drawOval(n.x - radio, n.y - radio, radio * 2, radio * 2);
            g2.drawString(n.id, n.x - 5, n.y + 5); // Texto del ID
        }
    }
    
public void eliminarNodoV(String id) {
    nodos.remove(id);
    
    aristas.removeIf(a -> a.origen.equals(id) || a.destino.equals(id));
    repaint();
}


public void eliminarAristaV(String origen, String destino) {
    aristas.removeIf(a -> a.origen.equals(origen) && a.destino.equals(destino));
    
    repaint();
}


public void destruirGrafoV() {
    nodos.clear();
    aristas.clear();
    repaint();
}
}